
<?php
$result = $connection->query("select FNumber, ActualArr from flight where ScheduledArr=ActualArr");
echo "<ol>";
while ($row = $result->fetch()) {
	echo "<tr><td>".$row["FNumber"]."</td><td>".$row["ActualArr"]."</td></tr>";
}
echo "</ol>";
?>
