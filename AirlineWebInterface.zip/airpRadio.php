

<?php
//airpRadio.php
include 'connectdb.php';
$query = "SELECT AirlineName FROM airline ";
   $result = $connection->query($query);
    $query2 = "SELECT DISTINCT AirportName FROM airport ";
   $result2 = $connection->query($query2);
   $result3 = $connection->query($query2);
   echo 'Airline:';
   echo '<br>';
while ($row = $result->fetch()) {
        echo '<br>';
        echo ' <input type="radio" name="airlinename" value="';
		echo $row["AirlineName"];
		echo '">' . $row["AirlineName"] .  "<br>";
		echo '<br>';
		}
		echo 'Departure Airport:';
		echo '<br>';
		while ($row = $result2->fetch()) {
		echo '<br>';
        echo ' <input type="radio" name="departureairport" value="';
		echo $row["AirportName"];
		echo '">' . $row["AirportName"] .  "<br>";
		echo '<br>';	
   }
   echo'Arrival Airport:';
   echo '<br>';
   while ($row = $result3->fetch()) {
		echo '<br>';
        echo ' <input type="radio" name="arrivalairport" value="';
		echo $row["AirportName"];
		echo '">' . $row["AirportName"] .  "<br>";
		echo '<br>';	
   }
   
?>



