

<?php
//flightNumRadio.php
include 'connectdb.php';
    $query = "SELECT FNumber FROM flight ";
   $result = $connection->query($query);
   echo 'Flight Number:';
while ($row = $result->fetch()) {
        echo '<br>';
        echo '<input type="radio" name="flightN" value="';
        echo $row["FNumber"];
        echo '">' . $row["FNumber"] .  "<br>";
		echo '<br>';
		}

?>
