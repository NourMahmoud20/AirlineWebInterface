<!DOCTYPE html>
<html>
<meta charset="utf-8">
<title>Flight</title>
<link rel="stylesheet" type="text/css" href="css1.css">
</head>
<body>
<style>
body{
background-image: url('airline4img.jpg');
  background-repeat: no-repeat;
   background-size:cover;
}
</style>
<div>
<h1>Here is the flight:</h1>

<?php
include 'connectdb.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {//Check it is coming from a form
	$u_ac = $_POST["airline_code"]; //set PHP variables like this so we can use them anywhere in code below
	$u_d = $_POST["day"];

	$query = 'SELECT DISTINCT flight.FNumber as flightCode, airport.City as DepLoc FROM flight, airport, day WHERE flight.AirpoCode=airport.AirportCode AND day.Fnumber=flight.FNumber AND flight.Acode="'.$u_ac.'" AND day.DayWeek="' . $u_d . '"';
	$query2 = 'SELECT DISTINCT flight.FNumber as flightCode, airport.City as ArrivalLoc FROM flight, airport, day WHERE flight.ArrivalAirpoCode=airport.AirportCode AND day.Fnumber=flight.FNumber AND flight.Acode="'.$u_ac.'" AND day.DayWeek="' . $u_d . '"';
    
	//missing arrving airport location
	$result= $connection->query($query);
	$result2= $connection->query($query2);
	
   
	  ?>
	  
	  <table>
	  <?php
	  

	
	

  // while ($row=$result->fetch() ) {
  
	
	if(empty($result->fetch())){
		echo "<td>Not found</td>";
		}
		else{
			$result= $connection->query($query);
	
	while ($row=$result->fetch() ) {
		 
	echo"<thead>";
    echo"<tr>";
    echo"<th>Flight Code</th>";
    echo "<th>Departure Location</th>";
	echo "<th>Arrival Location</th>";
    echo"</tr>";
    echo "</thead>";
	 
	echo "<tr>";
	
	echo"<td>".$row["flightCode"]."</td>";
	
	echo"<td>".$row["DepLoc"]."</td>";
	
   $row=$result2->fetch();
	  
	echo"<td>".$row["ArrivalLoc"]."</td>";
	echo"</tr>";
	
	}
	}
	
	
	
	}
	
	
	
	?>
	
	</div>
	</table>
	
	 

