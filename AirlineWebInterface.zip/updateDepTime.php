
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Update Times</title>
<link rel="stylesheet" type="text/css" href="css1.css">
<body>
<style>
body{
background-image: url('airline4img.jpg');
  background-repeat: no-repeat;
   background-size:cover;
}
</style>

<?php
//updateDepTime.php
include 'connectdb.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {//Check it is coming from a form
	$u_fn = $_POST["flightN"]; //set PHP variables like this so we can use them anywhere in code below
	$u_d = $_POST["Up_d"];
$query = 'UPDATE flight SET ActualDep="'.$u_d.'" WHERE FNumber="'.$u_fn.'"';
$result=$connection->exec($query);
echo " <div>";
echo " <h1>Record updated successfully </h1>"; 
echo "<br>";
?>
<table style="width 100%">
<?php
echo "<h2> Flight and Updated Departure Time: </h2>";
echo "<ol>";
echo "<tr><td>".$u_fn."</td><td>".$u_d."</td></tr>";
echo "</ol>";
echo "</div>";
	} 
?>
</table>
</body>
