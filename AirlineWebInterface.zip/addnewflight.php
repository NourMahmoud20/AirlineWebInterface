<!DOCTYPE html>
<html>
<title>Adding a New Flight</title>
<link rel="stylesheet" type="text/css" href="css1.css">
<body>
<style>
body{
background-image: url('airline4img.jpg');
  background-repeat: no-repeat;
   background-size: cover;
}
</style>

<?php
include 'connectdb.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {//Check it is coming from a form
	$a_n = $_POST["airlinename"]; //set PHP variables like this so we can use them anywhere in code below
	$a_d = $_POST["departureairport"];
	$a_a = $_POST["arrivalairport"];
	$f_num = $_POST["f_num"];
	$d_a = $_POST["day_f"];
	$sc_d= $_POST["sc_d"];
	$sc_a= $_POST["sc_a"];
	$ai_d= $_POST["AID"];
	
$a_ct = 'SELECT DISTINCT AirlineCode from airline where AirlineName = "' . $a_n . '"';
 $result_a=$connection->query($a_ct);
$a_t= 'SELECT DISTINCT AirportCode from airport where AirportName = "' . $a_d . '"';
$result_b=$connection->query($a_t);

$a_at= 'SELECT DISTINCT AirportCode from airport where AirportName = "' . $a_a . '"';
$result_c=$connection->query($a_at);

 while ($row=$result_a->fetch()) {
	$c_a= $row["AirlineCode"];
    //	echo $c_a;
    } 
	while ($row=$result_b->fetch()) {
	$p_a= $row["AirportCode"];
	//echo $p_a;
    } 
	while ($row=$result_c->fetch()) {
	$p_aa= $row["AirportCode"];
	//echo $p_aa;
    } 
	
	
	
	
$query2 = 'INSERT INTO flight values("' . $f_num . '","' . $sc_a . '","' . $sc_d . '", NULL, NULL,"'.$c_a.'", "' . $ai_d . '", "'  .$p_a. '", "'.$p_aa. '")';
$query3 = 'INSERT INTO day values("' . $f_num . '","' . $c_a . '","' . $d_a . '")';

   $ins_res = $connection->exec($query2);
   $query3_res= $connection->exec($query3);
      if ($ins_res == TRUE) {
    echo "<h1>Your flight was added!</h1>";
	
} else {
  echo "Error adding flight";
} 

    
}
?>

<table>
<thead>
<tr>
<th>Flight Code</th>
<th>Scheduled Arrival Time</th>
</tr>
</thead>

<?php
$result = $connection->query("select* from flight");
echo "<h2> All the flights in the database: </h2>";
echo "<ol>";
while ($row = $result->fetch()) {
	echo "<tr><td>".$row["FNumber"]."</td><td>".$row["ScheduledArr"]."</td></tr>";
}
echo "</ol>";
?>
</table>
   
   </body>
   
   