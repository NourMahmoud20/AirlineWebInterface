
<!DOCTYPE html>

<html>
<head>
<meta charset="utf-8">
<title>Average Number of Seats</title>
<link rel="stylesheet" type="text/css" href="css1.css">
</head>
<body>
<style>
body{
background-image: url('airline4img.jpg');
  background-repeat: no-repeat;
   background-size:cover;
}
</style>
<?php
include 'connectdb.php';
?>
<h1>Here is the average:</h1>

<?php
include 'connectdb.php';
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
   $u_da= $_POST['M'];
   $query='SELECT AVG(airplanetype.MaxSeat) as Avg
    FROM flight,airplane, airplanetype, day
    WHERE day.DayWeek="'.$u_da.'" AND flight.FNumber=day.Fnumber AND flight.AID=airplane.AirplaneId AND airplane.TypeName=airplanetype.TName';
   $result=$connection->query($query);
	  ?>
	  
	  <table>
	  
	  <?php
	   
$row=$result->fetch();
	if($row["Avg"]==NULL){
		echo "<td>Average = NULL</td>";
		}
		else{
			$result= $connection->query($query);
			
    while ($row=$result->fetch()) {
	echo "<h2> Average Number of Seats:</h2>";
	echo "<tr><td>" .$row["Avg"]. "</td></tr>";
    } 
	}
	}
	
	
?>
</table>
</body>

