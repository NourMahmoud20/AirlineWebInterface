<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Book Flights Over Different Airlines</title>
<link rel="stylesheet" type="text/css" href="css1.css">
</head>
<body>
<style>
body{
background-image: url('airline6img.jpg');
  background-repeat: no-repeat;
   background-size: 100% 100%;
}
</style>
<?php
include 'connectdb.php';
?>
    <h1>Welcome to CheapFlights</h1>
    <h2>Details About Flights</h2>
<table class="A">
<thead>
<tr>
<th>Flight Code</th>
<th>Arrival Time</th>
</tr>
</thead>
<?php
   include 'getdata.php';
?>
 </table>
<br>
<form action="getflight.php" method="post">
Airline Code:<input type="text" name="airline_code" placeholder="Airline Code"> Day: <input type="text" name="day" placeholder="Day">
<input  type="submit" name="sg" value="Submit">
<style>
input[type="submit"]{
    /* change these properties to whatever you want */
    background-color: #ffcc66;
    color:  #4d2600;
    border-radius: 10px;
}
</style>
</form>
<h2> Add a New Flight:</h2>
<form action="addnewflight.php" method="post">
Airplane ID:<input type="text" name="AID" placeholder="Airplane ID">
Scheduled Departure:<input type="text" name="sc_d" placeholder="Scheduled Departure">
Scheduled Arrival:<input type="text" name="sc_a" placeholder="Scheduled Arrival">
<br>
<?php
   include 'airpRadio.php';
?>
Flight Number:<input type="text" name="f_num" placeholder="Flight Number"> Day: <input type="text" name="day_f" placeholder="Day">;
<br>
<input  type="submit" name= "sa" value="Add Flight">
</br>
</form>
<h2> Update Departure Time</h2>
<form action="updateDepTime.php" method="post">
<?php
   include 'flightNumRadio.php';
?>
Update Departure Time:<input type="text" name="Up_d">
<input  type="submit" name="su" value="Update">
</form>
<h2> Average Number of Seats</h2>
<form action="calcAvg.php" method="post">
Day: <br>
<input type="radio" name="M" value="Monday">Monday<br>
<br>
<input type="radio" name="M" value="Tuesday">Tuesday<br>
<br>
<input type="radio" name="M" value="Wednesday">Wednesday<br>
<br>
<input type="radio" name="M" value="Thursday">Thursday<br>
<br>
<input type="radio" name="M" value="Friday">Friday<br>
<br>
<input type="radio" name="M" value="Saturday">Saturday<br>
<br>
<input type="radio" name="M" value="Sunday">Sunday<br>
<br>
<input type="submit" name="g_avg" value="Calculate Average Number of Seats">
</form>

<?php
   $connection = NULL;
?>
</body>
</html>